package com.cg.entity;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Admin {
	
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	private long adminId;
	

	@OneToOne
	private User user;
	
	/*@ManyToMany(cascade=CascadeType.MERGE)
	private Set<Account> accountlist=new HashSet<Account>();
	
	@OneToMany(cascade=CascadeType.MERGE)
	private List<Statement> statement;
	
	@OneToMany(cascade=CascadeType.MERGE)
	private List<CreditCard> creditcard;
	
	
	@OneToMany(cascade=CascadeType.MERGE)
	private List<Payment> transaction;*/
	

	public Admin() {
		super();
	}

	public Admin(User user) {
		super();
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	

	/*public Set<Account> getAccountlist() {
		return accountlist;
	}

	public void setAccountlist(Set<Account> accountlist) {
		this.accountlist = accountlist;
	}

	public List<Statement> getStatement() {
		return statement;
	}

	public void setStatement(List<Statement> statement) {
		this.statement = statement;
	}

	public List<CreditCard> getCreditcard() {
		return creditcard;
	}

	public void setCreditcard(List<CreditCard> creditcard) {
		this.creditcard = creditcard;
	}

	public List<Payment> getTransaction() {
		return transaction;
	}

	public void setTransaction(List<Payment> transaction) {
		this.transaction = transaction;
	}*/

	@Override
	public String toString() {
		return "Admin [user=" + user + "]";
	}
	
	
}
