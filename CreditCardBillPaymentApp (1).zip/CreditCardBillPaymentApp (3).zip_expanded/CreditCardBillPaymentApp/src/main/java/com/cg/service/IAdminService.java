package com.cg.service;

import java.util.List;

import com.cg.entity.Admin;
import com.cg.entity.Transaction;

public interface IAdminService {
	
	public Admin addAdmin(Admin admin);
	

}
