package com.cg.exceptions;

public class TransactionNotFoundException extends RuntimeException {
	
	public TransactionNotFoundException(String str)
	{
		super(str);
	}

	
	

}
