package com.cg.exceptions;

public class StatementNotFoundException extends RuntimeException {
	
	public StatementNotFoundException(String str)
	{
		super(str);
	}

	
	

}
